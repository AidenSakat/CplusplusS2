//------------------------------------------------------------------------------
// app_community_bike.cpp : base class declaration and definition
//------------------------------------------------------------------------------
// C:\\Users\\User\\inventory.txt
#include <iostream>
#include <string>
#include <ostream>
#include "inventory_app.h"
#include "Scooter.h"
#include "Bicycle.h"
#include <list>
using std::cout;
int main()
{
	Scooter sc;
	Bicycle bi;
	std::string filename;
	char option;
	cout << "Hello and Welcome! To begin please enter your file name here: ";
	std::cin >> filename;
	
	std::list<string>* inventory = doInventory(filename);

	cout << "\nAre you interested in renting a B)icycle or S)cooter?: ";
	while (std::cin >> option)
	{

		if (option == 'b' || option == 'B')
		{
			cout << "You chose bicycle! What frame height would you like?: ";
			int frameHeight;
			std::cin >> frameHeight;

			// Filter inventory by frame height and display
			std::list<string> filteredInventory = bi.filterBicycleInventory(inventory, frameHeight);
			bi.displayBicycleInventory(&filteredInventory);
			break;
		}
		else if (option == 's' || option == 'S')
		{
			cout << "You chose Scooter! What is the minimum horsepower that you would like?: ";
			double minHorsepower;
			std::cin >> minHorsepower;
			std::list<string> filteredInventory = sc.filterScooterInventory(inventory, minHorsepower);
			sc.displayScooterInventory(&filteredInventory);
			break;
		}
		else
		{
			cout << "\nInvalid input. Please enter B for bicycle or S for scooter: ";
		}
	}
}