#include <string>
#include <list>
#ifndef INVENTORY_APP_H
#define INVENTORY_APP_H

std::list<std::string>* doInventory(std::string filename);
#endif 