#pragma once
#include "TwoWheeler.h"

class Bicycle : public TwoWheeler
{
public:

	// Displays the inventory and puts the type of vehicle in the beginning instead of numbers
	static bool isBicycle(const string& str) {return str.substr(0, 1) == "1" && std::isdigit(str.back());}
    void displayBicycleInventory(std::list<string>* inventoryList)
    {
        std::for_each(inventoryList->begin(), inventoryList->end(), [](string item) {
            if (isBicycle(item)) {
                std::istringstream iss(item);
                int type;
                std::string brand, model, serial, frameHeight;
                iss >> type >> brand >> model >> serial >> frameHeight;
                brand += " " + model;
                std::cout << "Bicycle: " << brand << " (Serial Number: " << serial << " (Frame Height: " << frameHeight << std::endl;
            }
            });
    }

	void displayBicycleCounts(std::list<string>* inventoryList) // displays number of bicycles
	{
		int bicycleCount = std::count_if(inventoryList->begin(), inventoryList->end(), isBicycle);
		std::cout << "Number of bicycles: " << bicycleCount << std::endl;
	}

    std::list<string> filterBicycleInventory(std::list<string>* inventory, int frameHeight) {
        std::list<string> filteredInventory;

        for (const string& item : *inventory) {
            std::istringstream iss(item);
            int type;
            string brand, model, serial;
            int bicycleFrameHeight;
            iss >> type >> brand >> model >> serial >> bicycleFrameHeight;

            if (type == 1 && bicycleFrameHeight == frameHeight) {
                filteredInventory.push_back(item);
            }
        }
        return filteredInventory;
    }
};