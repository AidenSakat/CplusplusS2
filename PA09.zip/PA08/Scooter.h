#ifndef SCOOTER_H
#define SCOOTER_H

#include "TwoWheeler.h"
#include <string>
#include <iostream>
#include <fstream>
using std::string;
class Scooter : public TwoWheeler 
{
public:

	// Displays the inventory and puts the type of vehicle in the beginning instead of numbers
	static bool isScooter(const string& str) { return str.substr(0, 1) == "2" && std::isdigit(str.back()); }
    void displayScooterInventory(std::list<string>* inventoryList) // display scooters in inventory,
    {
        std::for_each(inventoryList->begin(), inventoryList->end(), [](string item) {
            if (isScooter(item)) {
                std::istringstream iss(item);
                int type;
                std::string brand, model, horsePower;
                iss >> type >> brand >> model>> horsePower;
                brand += " " + model;
                std::cout << "Scooter: " << brand << " (HorsePower: " << horsePower << std::endl;
            }
            });
    }

	// displays how many scooters in the file
	void displayScooterCounts(std::list<string>* inventoryList) {
		int scooterCount = std::count_if(inventoryList->begin(), inventoryList->end(), isScooter);
		std::cout << "Number of Scooters: " << scooterCount << std::endl;
	}

    std::list<string> filterScooterInventory(std::list<string>* inventory, double minHorsepower) {
        std::list<string> filteredInventory;

        for (const string& item : *inventory) {
            std::istringstream iss(item);
            int type;
            string brand, model;
            double horsepower;
            iss >> type >> brand >> model >> horsepower;

            if (type == 2 && horsepower >= minHorsepower) {
                filteredInventory.push_back(item);
            }
        }
        return filteredInventory;
    }
}; 
#endif