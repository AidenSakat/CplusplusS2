//------------------------------------------------------------------------------
// Circle class declaration and definition
//------------------------------------------------------------------------------
#ifndef CIRCLE_H
#define CIRCLE_H

class Circle {
public:
	int radius;

	Circle(int r) : radius(r) {}
	
	bool operator==(const Circle& c) const
	{
		return radius == c.radius;
	}
	bool operator>(const Circle& c) const
	{
		return radius > c.radius;
	}
	bool operator<<(const Circle& c) const
	{
		return radius << c.radius;
	}
	friend std::ostream& operator<<(std::ostream& os, const Circle& c)
	{
		os << "Radius " << c.radius;
		return os;
	}
};

#endif	// CIRCLE_H
