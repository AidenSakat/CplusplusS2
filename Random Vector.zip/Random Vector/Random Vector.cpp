
#include <iostream>
#include <vector>
using std::cout;
using std::cin;
using std::endl;

int main()
{
	int user_input = 0;
	int random_numbers = 0;
	srand(time(0));
	std::vector <int> vec;

	cout << "This program will generate a random number from 1 up to your typed number. 0 to quit. " << endl; 
	cin >> user_input; //User prompt

	while (user_input != 0) // Loop to keep asking for user input until user inputs 0
	{

		if (user_input < 0) //Turns negative input to a positive
		{
			user_input = user_input * -1;
		}

		if (user_input == 0) // Exits program if user inputs 0
		{
			exit(0);
		}

		for (int i = 0; i < 10; i++) // Generates random 10 numbers up to users input
		{
			random_numbers = (rand() % user_input) + 1;

		 vec.push_back(random_numbers);

		 cout << i + 1 << ":" << vec.at(i) << " ";
		}
		cout << "\n\n";

		while (!vec.empty()) // Displays the vector in backwards order
		{
			for (int i = 10; i > 0; i--)
			{
				cout << i << ":" << vec.back() << " ";
				vec.pop_back();
			}
		}

		cin >> user_input;
	}

}
